#include<stdio.h>

int *test(int x)	
{
	static int y;
	y=x*x;
	return &y;
}

int main(){
	int x,*y;
	printf("enter value of x:\n");
	scanf("%d",&x);
	y=test(x);
	printf("%d\n",*y);
	return 0;
}
