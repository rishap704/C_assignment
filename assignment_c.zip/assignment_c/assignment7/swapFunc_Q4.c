#include<stdio.h>

int* swapbyval(int num1,int num2)
{
	static int arr[2];
	arr[0]=num2;
	arr[1]=num1;
	return arr;	
}
int swapbyref(int*num1,int*num2){
	
	int temp;
	temp=*num1;
	*num1=*num2;
	*num2=temp;
	return 0;
}
int main()
{
	int num1,num2;
	int *p;   
	printf("enter 2 numbers");
	scanf("%d%d",&num1,&num2);
	p=swapbyval(num1,num2);
	num1=*p;
	num2=*(p+1);
	printf("\n swap by val num1=%d num2=%d",num1,num2);
	swapbyref(&num1,&num2);
	printf("\n swap by ref num1=%d num2=%d",num1,num2);
return 0;
}


