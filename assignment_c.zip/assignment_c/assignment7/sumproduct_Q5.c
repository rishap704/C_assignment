#include<stdio.h>
   int*	sumprod(int num1,int num2){
        static int arr[2]={0,1};
	arr[0]=num1+num2;
	arr[1]=num1*num2;
	return arr;
	}
int main(){
	int num1,num2;
	int *p;
	printf("enter two number\n");
	scanf("%d%d",&num1,&num2);
	p=sumprod(num1,num2);
	printf("sum is%d & product is %d",p[0],p[1]);
	return 0;

}
