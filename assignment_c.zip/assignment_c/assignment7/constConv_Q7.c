#include<stdio.h>

void test1(const int *b)
{	//*b=*b+3;
	printf("\n test1:: *p=%d",*b);
}

void test2(int *a)
{	
	*a=(*a)+2;
	printf("\n test2:: *q=%d",*a);
}

int main()
{
	int x=10,y=20;
	int *p=&x;
	const int *q=&y;
	//*q=25;
	test1(p);
	test1(q);
	test2(p);
	test2(q);
return 0;
}
