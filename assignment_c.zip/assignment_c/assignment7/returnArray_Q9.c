#include<stdio.h>

int*fun1(void){
	static int arr[6]={1,2,3,4,5,6};
  	return arr;
          
}

int (*fun2())[2]{
	static int arr[2]={1,2};
	return &arr;

}
int main(){

	int *p,(*q)[2];
	p=fun1();
	for(int i=0;i<6;i++)
		printf("%d ",*(p+i));
	q=fun2();
	printf("\narray of fun2 is=%d",**q);
	printf("\n2nd ele of arr is=%d \n",*(*q)+1);
	return 0;

}
