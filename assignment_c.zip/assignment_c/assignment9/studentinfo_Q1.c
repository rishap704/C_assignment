#include<stdio.h>
#include<stdio_ext.h>
#include<stdlib.h>
#include<string.h>

typedef struct student{
	char *name;
	int rollno;
	float marks;
	float attendence;
}stu;

void display(stu *);

int main(){
	int n,i=0;
	char tempname[60];
	printf("Enter no of students");
	fscanf(stdin,"%d",&n);
	stu *s1=(stu*)malloc(sizeof(stu)*n);
	
	do
	{
	__fpurge(stdin);
	printf("Enter name");
	fgets(tempname,60,stdin);
	(s1+i)->name=(char *)malloc(strlen(tempname)+1);
	strcpy((s1+i)->name,tempname);
	
	printf("Enter rollno");
	fscanf(stdin,"%d",&((s1+i)->rollno));
	
	printf("Enter marks");
	fscanf(stdin,"%f",&((s1+i)->marks));

	printf("Enter percentage of attendence");
	fscanf(stdin,"%f",&((s1+i)->attendence));

	i++;
	}
	while(i<n);
	i=0;
	printf("\n Name		rollno		marks		attendence");

	while(i<n)
	{
	display(s1+i);
	i++;
	}
}

void display(stu *p)
{
	
	printf("\n %s",p->name);
	printf("\t \t %d",p->rollno);
	printf("\t \t %f",p->marks);
	printf("\t \t %f",p->attendence);
}
