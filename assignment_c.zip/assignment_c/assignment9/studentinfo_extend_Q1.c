
#include<stdio.h>
#include<stdio_ext.h>
#include<stddef.h>
#include<string.h>

typedef struct student{
	char name[5];
	int rollno;
	float marks;
	float atd;
}stu;



int main(){
	stu s1={'a',78,45};
	//printf("name is=%s\n",s1.name);
	printf("roll no=%d\n",s1.rollno);
	printf("marks=%f\n",s1.marks);
	printf("attendence=%f\n",s1.atd);
	printf("size=%ld",sizeof(s1));
	printf("ofset of name=%ld",offsetof(stu,name));
	printf("ofset of rollno=%ld",offsetof(stu,rollno));
	printf("ofset of marks=%ld",offsetof(stu,marks));
	printf("ofset of attendence=%ld",offsetof(stu,atd));

	return 0;
	
}
