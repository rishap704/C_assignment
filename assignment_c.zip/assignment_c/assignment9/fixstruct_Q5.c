
#include<stdio.h>
#include<string.h>
struct A
{
int x;
char str[20]; // (or) char str[20];
};

int main(){
struct A a1 = { 101,"abc" },a2;
//char *str="rishap";
a1.x=10;
char r[17];
//int x=20;
//str=(char*)(&x);
//a1.str="hello"; //works?i
strcpy(a1.str,"asdfgh");
printf("a1.x=%d",a1.x);
//str='c';
//a1.str=r;
printf("a1.str=%d %s",a1.x,a1.str);
scanf("%d%s",&a1.x,a1.str); //works?
printf("a1.str=%s",a1.str);
a2 = a1; //shallow copy or deep copy?
return 0;
}
