#include<stdio.h>


struct book{
	char title[10];
	int bookid;
};
struct stud{
	char name[10] ;
	int rollno;
	struct book book1;
};

int main(){
	struct stud s1={"rishap",99,{"C prog",87}};
	printf("name=%s rollno=%d %s %d",s1.name,s1.rollno,s1.book1.title,s1.book1.bookid);
	return 0;
}
