#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <stdio_ext.h>


typedef struct node{
	char *name;
	int id;
	float sal;
	int year;
	struct node *next;
}emp;

void insertATend(emp**);
void display(emp*);
void insertatbeg(emp**);
emp *createnode();
void insertatpos(emp**);
void delAtbeg(emp**);
void delAtpos(emp**);
void delAtend(emp**);

int main(){
	emp *head=NULL;
	int choice;
	
	while(1){
		printf("\n 1:Add at end 2:display 3:add at beg 4:add at pos 5:del at beg 6:del at pos 7:del At end 8:exit\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insertATend(&head);
				break;
			case 2:
				display(head);
				break;
			case 3:
				insertatbeg(&head);
				break;
			case 4:
				insertatpos(&head);
				break;	
			case 5:
				delAtbeg(&head);
				break;	
			case 6:
				delAtpos(&head);
				break;	
			case 7:
				delAtend(&head);
				break;	
			case 8:
				exit(0);
				break;
			default:
				printf("enter good choice\n");
				break;
		}
	}
}

void delAtbeg(emp **head)
{
	if(*head!=NULL)
	{
	emp *temp=*head;
	temp=temp->next;
	free(*head);
	*head=temp;
	}
	else
	{
	printf("\nno node left\n");
	}
}
void delAtpos(emp **t){
	int pos;
	printf("enter position\n");
	scanf("%d",&pos);
	emp *temp1,*temp2;
	temp1=*t;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
	}
	temp2->next=temp1->next;
	if(temp1==*t)
	{
		delAtbeg(t);
	}
	free(temp1);
	
}

void delAtend(emp **t)
{
	emp *temp1,*temp2;
	temp1=*t;
	while(temp1->next != NULL)
	{
		temp2=temp1;
		temp1=temp1->next;
	}
	if(temp1 != *t)
	{
	temp2->next=NULL;
	//free(temp1);
	}
	else
	{
		delAtbeg(t);
	}
	free(temp1);
	
}
void insertatpos(emp **t){
	int pos;
	printf("enter position\n");
	scanf("%d",&pos);
	emp *temp=createnode();
	emp *temp1,*temp2;
	temp1=*t;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
	}
	temp->next=temp1;
	temp2->next=temp;
}

void insertatbeg(emp **t){

	emp *temp=createnode();
	temp->next=*t;
	*t=temp;
}
emp * createnode(void){
	emp *temp;
	char buff[50];        
	int x,z;
	float y;
	printf("\nname,id,sal and year of employee\n");
	temp=(emp*)malloc(sizeof(emp));		
	scanf("%s%d%f%d",buff,&(temp->id),&(temp->sal),&(temp->year));	
	temp->name=(char*)malloc(strlen(buff));
	strcpy(temp->name,buff);
	printf("test strcpy passed");
	temp->next=NULL;
	return temp;
}
void insertATend(emp **t)
{	
	emp *temp=createnode();
	if(*t==NULL)
	{
		*t=temp;
	}
	else
	{	
		emp *t1=*t;
		while(t1->next != NULL)
		{
			t1=t1->next;
		}
		t1->next=temp;	
	}
}

void display(emp *t)
{
	while(t!=NULL)
	{
		printf("\n name::%s \t id::%d \t sal::%f \t year::%d \n",t->name,t->id,t->sal,t->year);
		t=t->next;
	}	
	
}





















