#include<stdio.h>
#include<stddef.h>


struct stu{
	int x;
	double y;
	float z;
	char ch;
};

int main(){
	struct stu a1;
	long int o,p;
	p=&(a1.z);
	o=offsetof(struct stu,z);
	printf("original base address is%ld\n",&a1.x);
	printf("base address is %ld",(p-o));
}
