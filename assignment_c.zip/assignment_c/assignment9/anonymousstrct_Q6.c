#include<stdio.h>
typedef struct {
	int x;
	float y;
struct {
	char ch;
};

}s1;


int main(){

	s1 a1;
	a1.x=5;
	a1.y=6.76;
	a1.ch='r';
	printf("int=%d",a1.x);
	printf("float val=%f",a1.y);
	printf("char=%c",a1.ch);
}
