
#include<stdio.h>
int gcd(int,int);
static int gcdno;

int main(){
	int num1,num2,temp;	
	printf("enter two numbers");
	scanf("%d%d",&num1,&num2);
	if(num2>num1)
	{
		temp=num1;
		num1=num2;
		num2=temp;
	}
	gcd(num1,num2);
	printf("gcd of%d and %d is =%d",num1,num2,gcdno);
return 0;
}


int gcd(int num1,int num2){
	if(num1>0){
		gcdno=num1;
		gcd(num2%num1,num1);
	}
	return 0;
}
