
#include<stdio.h>
int power(int,int);
	static int result=1;
int main(){
	int b,p;
	printf("ENTER BASE AND POWER");
	scanf("%d%d",&b,&p);
	power(b,p);
	printf("power is %d",result);
	return 0;
}
        int power(int b,int p){
	if(p>0){
	result=result*b;
	p--;
	
	return power(b,p);
	}
	else 
		return 0;

	
	
	}
