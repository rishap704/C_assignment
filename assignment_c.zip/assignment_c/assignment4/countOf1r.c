#include<stdio.h>

int dec2bin(int);
int bincount(int);
static int zero=0,one=0;
int main(){
	int num;
	printf("Enter the dec Num");
	scanf("%d",&num);
	dec2bin(num);
	bincount(num);
	printf("\nCount of one's::%d \n",one);
	printf("\nCount of zero::%d \n",zero);
	return 0;
}

int dec2bin(int num){
	if(num>0)
	{
		dec2bin(num/2);
		printf(" %d",num%2);
	}
	else
		return 0;
}

int bincount(int num){
	if(num>0)
	{
		bincount(num/2);
		if(num%2==1)
			one++;
		else
			zero++;
	}
	else
		return 0;
}

