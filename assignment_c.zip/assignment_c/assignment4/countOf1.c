#include<stdio.h>

int dec2bin(int);
int bincount(int);
int main(){
	int num;
	printf("Enter the dec Num");
	scanf("%d",&num);
	dec2bin(num);
	bincount(num);
	return 0;
}

int dec2bin(int num){
	if(num>0)
	{
		dec2bin(num/2);
		printf(" %d",num%2);
	}
	else
		return 0;
}

int bincount(int num){
	int zero=0,one=0;
	while(num>0)
	{
		if(num%2==1)
			one++;
		else
			zero++;
		num=num/2;
	}
	printf("\nCount of one's::%d \n",one);
	printf("\nCount of zero::%d \n",zero);
	return 0;
}

