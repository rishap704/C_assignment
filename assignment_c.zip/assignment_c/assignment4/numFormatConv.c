#include<stdio.h>
int dec2bin(int);
int dec2oct(int);
int main(){
	int num,bnum,onum;
	printf("enter a decimal number: \n");
	scanf("%d",&num);
	printf("DEC to BIN:");
	dec2bin(num);
	printf("\n DEC to OCT:");
	dec2oct(num);
	return 0;
}

int dec2bin(int num){
	int n=num,m=0;
	int count=0,i=num;
	while(i>0){
		count++;
		i=i/2;
	}
	for(int i=count;i>0;i--){
		n=num;
		for(int j=i;j>0;j--){
			m=n%2;
			n=n/2;	
		}
	printf("%d ",m);
	}	
	return 0;
}

int dec2oct(int num){
	int n=num,m=0;
	int count=0,i=num;
	while(i>0){
		count++;
		i=i/8;
	}
	for(int i=count;i>0;i--){
		n=num;
		for(int j=i;j>0;j--){
			m=n%8;
			n=n/8;	
		}
	printf("%d ",m);
	}	
	return 0;
}
