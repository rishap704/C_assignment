#include<stdio.h>
int main(){
	int num,count=0;
	printf("enter a number");
	scanf("%d",&num);
	while(num){
		num=num/10;
		++count;
	}
	printf("number of digits:%d\n",count);
	return 0;
}
