
#include<stdio.h>
int fact(int);

int main(){
int n;	
printf("enter number");
scanf("%d",&n);
printf("factorial is %d",fact(n));
}

int fact(int n){
if(n==0)
	return 1;
return n=n*fact(n-1);

}
