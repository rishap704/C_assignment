
#include<stdio.h>
#include<string.h>

int display(char*,int);
int displayReverse(char*,int);

int main()
{
	char arr[20],ch='r';
	int n;
		//printf("enter the no of elements");
		//scanf("%d",&n);
	printf("enter string \n");
	scanf("%s",arr);
	n=strlen(arr);

	printf("n=%d\n",n);
	printf("String display\n");
	display(arr,n);
	printf("Reverse String display\n");
	displayReverse(arr,n);
	printf("\n");
}

int displayReverse(char *p,int n)
{	//static int i=n;
	
		printf("%c \t",p[--n]);
	if(n>0)
		displayReverse(p,n);
	else
		return 0;
}

int display(char *p,int n)
{	static int i=0;
	
		printf("%c \t",p[i++]);
	if(i<n)
		display(p,n);
	else
		return 0;
}

