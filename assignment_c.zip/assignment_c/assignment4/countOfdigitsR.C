#include<stdio.h>
int digits(int);
int main(){
	int num,count=0;
	printf("enter a number");
	scanf("%d",&num);
	printf("number of digits:%d\n",digits(num));
	return 0;
}

int digits(int num)
{
	static int count=0;
	if(num>0){
		count++;
		digits(num/10);
	}
	return count;
}
