#include<stdio.h>

int fibo(int,int,int);

int main(){
	int n;
	printf("enter number of terms to print");
	scanf("%d",&n);
	printf("%d",1);
	fibo(0,1,n);
	printf("\n");
	return 0;
}

int fibo(int a,int b,int n)
{
	if(n>1)
	{
		int c=a+b;
		a=b;
		b=c;
		printf(" %d",b);
	     	fibo(a,b,--n);
		//printf(" %d",b);
	}
	else
	return 0;
}

