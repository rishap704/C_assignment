#include<stdio.h>

int main(){
	int num1,num2,k=0,i,j;	
	printf("enter two numbers");
	scanf("%d%d",&num1,&num2);
	i=num1;

	while(i>0){
		j=num2;
		if(num1%i==0){
			while(j>0){
				if(num2%j==0){
					if(i==j && i>k)
						k=j;
				
				}
			j--;
			}
		}
		i--;
	}
printf("gcd of%d and %d is =%d",num1,num2,k);
return 0;
}
