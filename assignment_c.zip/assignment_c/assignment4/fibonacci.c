#include<stdio.h>
int main(){
	int n;
printf("enter number of terms to print");
scanf("%d",&n);
printf("%d",1);
int a=0,b=1,c=0;
while(n>1)
{
c=a+b;
printf(" %d",c);
a=b;
b=c;
n--;

}
printf("\n");
return 0;
}
