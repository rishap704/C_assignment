#include<stdio.h>
int main(){
	int b,p,result=1;;
	printf("ENTER BASE AND POWER");
	scanf("%d%d",&b,&p);
	for(int i=0;i<p;i++)
		result=result*b;
	printf("power is %d",result);
	return 0;
}
