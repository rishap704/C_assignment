#include<stdio.h>

int display(int*,int);

int main()
{
	int arr[20],n;
	printf("enter the no of elements");
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%d",&arr[i]);
	display(arr,n);
}

int display(int *p,int n)
{	//static int i=n;
	
		printf("%d \t",p[--n]);
	if(n>0)
		display(p,n);
	else		
		return 0;
}
