#include<stdio.h>

int dec2bin(int);
int dec2oct(int);
int main(){
	int num;
	printf("Enter the dec Num");
	scanf("%d",&num);
	printf("DEC to BIN::");
	dec2bin(num);
	printf("\nDEC to OCT::");
	dec2oct(num);
	return 0;
}

int dec2bin(int num){
	if(num>0)
	{
		dec2bin(num/2);
		printf(" %d",num%2);
	}
	else
		return 0;
}

int dec2oct(int num){
	if(num>0)
	{
		dec2oct(num/8);
		printf(" %d",num%8);
	}
	else
		return 0;
}
