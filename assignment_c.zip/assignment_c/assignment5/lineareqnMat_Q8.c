
#include<stdio.h>
#include<math.h>

int mat3det(int (*arr)[]);
int mat2det(int *);
int main(){
	int r1,c1,c=-1;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);

	int mat1[r1][c1],det=0,temp[r1][r1];	
	char ch[3]={'X','Y','Z'};
	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}
	
//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	if(r1==2)
	{	
		while(c<r1)
		{
		for(int i=0;i<r1;i++){
			for(int j=0;j<r1;j++)
			{
				if(j!=c)
				{
					temp[i][j]=mat1[i][j];
				}
				else
				{
					temp[i][j]=mat1[i][2];
				}
			}
		}	
		if(c>=0)
			printf("Value of %c= %d",ch[c],mat2det(temp)/det);
		else
			det=mat2det(temp);
		c++;
		}
	}
	else if(r1==3)
	{
		while(c<3)
		{
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++)
			{
				if(j!=c)
				{
					temp[i][j]=mat1[i][j];
				}
				else
				{
					temp[i][j]=mat1[i][3];
				}
			}
		}	
		if(c>=0)
			printf("Value of %c= %d",ch[c],mat3det(temp)/det);
		else
			det=mat3det(temp);
		c++;
		}
	}
return 0;	
}

int mat2det(int *arr)
{	
	printf("\ntemp mat::");
	for(int i=0;i<4;i++)
	printf("%d ",*(arr+i));
	printf("\n detrminant::%d",((*arr)*(*(arr+3))-((*(arr+1))*(*(arr+2)))));
	return ((*arr)*(*(arr+3))-((*(arr+1))*(*(arr+2))));
}

int mat3det(int (*arr)[3])
{	
	int z=0,temp[4],det=0,b=1;
		for(int j=0;j<3;j++){
		z=0;
			for(int l=1;l<=2;l++){
				for(int m=0;m<=2;m++)
				{
					if(m!=j)
					{
						
					temp[z]=arr[l][m];
					z++;
					}
					
				}
			}
			//det=det+(mat1[0][j]*(int)pow((double)-1.0,(double)j)*mat2det(temp));
			if(j==1)b=-1;
			else b=1;
			det=det+(arr[0][j]*b*mat2det(temp));
		}
	printf("\n determinantof 3x3=%d \n",det);
return det;
}
