#include<stdio.h>

int main(){
	int r1,c1;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);

	int mat1[r1][c1],trans[c1][r1];	

	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}

//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	
//Transpose calculation print*******************************
	
	for(int i=0;i<c1;i++){
		for(int j=0;j<r1;j++){
		trans[i][j]=mat1[j][i];
		}
		
	}

	for(int i=0;i<c1;i++){
		for(int j=0;j<r1;j++){
		printf("%d ",trans[i][j]);
		}
		printf("\n");
	}
	return 0;
}	

