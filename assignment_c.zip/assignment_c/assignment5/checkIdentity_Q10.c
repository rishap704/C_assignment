
#include<stdio.h>
int main(){
	int r1,c1,c=-1;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);

	int mat1[r1][c1],temp[r1][r1];	
	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}
	
//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
			if(mat1[i][j]==1 && mat1[j][j])
				printf("given matrix is identity");
			else
				printf("given matrix is not identity");
	}
	}
return 0;
}
















	
