#include<stdio.h>
#include<math.h>
int main(){
	int n,a[50],sum=0;
	printf("enter degree of polynomials");
	scanf("%d",&n);
	printf("enter coefficients");
	for(int i=0;i<n+1;i++)
		scanf("%d",&a[i]);
	int x;
	printf("enter value of x");
	scanf("%d",&x);
	for(int j=0;j<=n;j++)
	sum=sum+a[j]*(int)pow((double)x,(double)n-j);
	printf("result is %d\n",sum);
	return 0;	
}
