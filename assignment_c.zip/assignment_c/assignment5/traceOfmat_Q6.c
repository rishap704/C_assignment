
#include<stdio.h>

int main(){
	int r1,c1;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);

	int mat1[r1][c1],sum=0;	

	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}

//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	
//Trace calculation print*******************************
	
	for(int i=0;i<c1;i++){
		sum=sum+mat1[i][i];
		}
	printf("trace of matrix is= %d",sum);	
	return 0;
}	

