
#include<stdio.h>
	int main(){
		int n,a[50],b[50];
		printf("enter a number");
		scanf("%d",&n);
	
		printf("enter array1");
		for(int i=0;i<n;i++)
	        scanf("%d",&a[i]);
		printf("enter array2");
		for(int i=0;i<n;i++)
	        scanf("%d",&b[i]);
		printf("\narray1:");
		for(int i=0;i<n;i++)
		        printf(" %d",a[i]);
		
		printf("\narray2:");
		for(int i=0;i<n;i++)
		        printf(" %d",b[i]);
                for(int j=0;j<n;j++)
			a[j]=a[j]+b[j];
		
		printf("\nAddition of two array:");
		for(int i=0;i<n;i++)
		        printf(" %d ",a[i]);
		return 0;	                  
}
