#include<stdio.h>
#include<math.h>

int mat2det(int *);
int main(){
	int r1,c1;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);

	int mat1[r1][c1],det=0,temp[4];	

	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}

//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	int b=1,z=0;
	if(r1==2)
	{
	printf("\n determinant=%d",mat2det(mat1));
	}
	else if(r1==3)
	{	
		for(int j=0;j<3;j++){
		z=0;
			for(int l=1;l<=2;l++){
				for(int m=0;m<=2;m++)
				{
					if(m!=j)
					{
						
					temp[z]=mat1[l][m];
					z++;
					}
					
				}
			}
			//det=det+(mat1[0][j]*(int)pow((double)-1.0,(double)j)*mat2det(temp));
			if(j==1)b=-1;
			else b=1;
			det=det+(mat1[0][j]*b*mat2det(temp));
		}
	printf("\n determinantof 3x3=%d \n",det);
	}
	else
		printf("\nmatrix should be 2x2 or 3x3\n");

return 0;	
}

int mat2det(int *arr)
{	
	printf("\ntemp mat::");
	for(int i=0;i<4;i++)
	printf("%d ",*(arr+i));
	return ((*arr)*(*(arr+3))-((*(arr+1))*(*(arr+2))));
}
