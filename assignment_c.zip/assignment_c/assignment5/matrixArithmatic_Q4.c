#include<stdio.h>


void add(int *mat1,int *mat2,int r1,int c1,int r2,int c2)
{	  
	printf("addition of mat1::mat2\n");
	for(int i=0;i<r1*c1;i++){
		if(( i%c1)==0)
		{
		printf("\n");
		}
		printf("%d ",(*(mat1+i)+*(mat2+i)));
	}	
}

void sub(int *mat1,int *mat2,int r1,int c1,int r2,int c2)
{	  
	printf("addition of mat1::mat2\n");
	for(int i=0;i<r1*c1;i++){
		if(( i%c1)==0)
		{
		printf("\n");
		}
		printf("%d ",(*(mat1+i)-*(mat2+i)));
	}	
}
/*void mul_try(int *mat1,int *mat2,int r1,int c1,int r2,int c2)
{	  
	printf("addition of mat1::mat2\n");
	for(int i=0;i<r1*c1;i++){
		if(( i%c1)==0)
		{
		printf("\n");
		}
		printf("%d ",(*(mat1+i)+*(mat2+i)));
	}	
}*/
int main(){
	int r1,r2,c1,c2;  // r1 row of matrix1, r2 row of matrix2	
	printf("enter no of row amd column of matrix1:\n");
	scanf("%d%d",&r1,&c1);
	printf("enter num of row amd column of matrix2:\n");
	scanf("%d%d",&r2,&c2);
	int mat1[r1][c1],mat2[r2][c2];	

	printf("enter matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		scanf("%d",&mat1[i][j]);
		}
	}
	printf("enter matrix1:\n");
	for(int i=0;i<r2;i++){
		for(int j=0;j<c2;j++){
		scanf("%d",&mat2[i][j]);
		}
	}
//mat1***********************************	
	printf("matrix1:\n");
	for(int i=0;i<r1;i++){
		for(int j=0;j<c1;j++){
		printf("%d ",mat1[i][j]);
		}
		printf("\n");
	}
	
//mat2 print*******************************
	printf("matrix2dd:\n");
	for(int i=0;i<r2;i++){
		for(int j=0;j<c2;j++){
		printf("%d ",mat2[i][j]);
		}
		printf("\n");
	}
	
	printf("mul of mat::\n");
	int n=0,sum=0;

	while(n<r1)
	{
		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<r1;j++)
			{
				sum=(mat1[n][j]*mat2[j][i])+sum;		
			}
			printf("%d ",sum);
			sum=0;
		}
		printf("\n");
	n++;
	}
	
	add(mat1,mat2,r1,c1,r2,c2);

	sub(mat1,mat2,r1,c1,r2,c2);
	
	return 0;
}	

