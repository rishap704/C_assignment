#include<stdio.h>
	int main(){
		int n,a[50],temp;
		printf("enter a number");
		scanf("%d",&n);
	
		printf("enter inputs");
		for(int i=0;i<n;i++)
	        scanf("%d",&a[i]);
		printf("array:");
		for(int i=0;i<n;i++)
		        printf(" %d",a[i]);

                for(int j=0;j<n/2;j++){
			temp=a[j];
			a[j]=a[n-j-1];
		        a[n-j-1]=temp;
		}	
		printf("\nReverse array:");
		for(int i=0;i<n;i++)
		        printf(" %d ",a[i]);
		return 0;	                  
}
