#include<stdio.h>
#include<stdlib.h>
#define limit 5

typedef struct queue{
	int x;
	struct queue *next;

}que;

que* createnode(void);
void insert(que** ,int*,int*);
void display(que*);
void delete(que**,int*,int*);
void delAtend(que**);
void delAtbeg(que**);

int main()
{
	que *point=NULL;
	int f=-1,r=-1,choice;
	while(1)
	{
	printf("1:insert 2:delete 3:display 4:exit\n");
	scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insert(&point,&f,&r);
			break;	
			case 2:
				delete(&point,&f,&r);
			break;	
			case 3:
				display(point);
			break;	
			case 4:
				exit(0);
			break;	
		}
}}



que * createnode(void){
	que *temp;
	printf("\nenter a number\n");
	temp=(que*)malloc(sizeof(que));		
	scanf("%d",&(temp->x));	
	temp->next=temp;
	return temp;
}

void delAtbeg(que **head)
{
	if(*head==NULL)
		return;
	if((*head)->next!=*head)
	{
	que *temp=*head,*temp1;
	temp=temp->next;
		temp1=temp;
		while(temp1->next!=*head)
		{
			temp1=temp1->next;
		}

		temp1->next=temp;
		free(*head);
		*head=temp;
	}
	else
	{
		if(*head!=NULL)
		{
			*head=NULL;
			return;
		}
	printf("\nno node left\n");
	}
}

void delAtend(que **t)
{
	que *temp1,*temp2;
	if((*t)->next==*t)
	{
		delAtbeg(t);
	}
	temp1=*t;
	while(temp1->next != *t)
	{
		temp2=temp1;
		temp1=temp1->next;
	}
	temp2->next=temp1->next;
	free(temp1);
}

void delete(que **head,int *f,int *r)
{	
	if(*f==*r)
	{

		delAtbeg(head);
		*f=-1;
		*r=-1;
		printf("que is Empty \n");
		return;
	}
	else if(*f==-1)
	{
		printf("que is Empty \n");
		return;
	}	
	else 
	{
		delAtend(head);
		(*f)++;
	}
}
void insert(que **t,int *f,int *r)
{	
	if( (*r==limit-1 && *f==0) || (*r+1==*f) )
	{
		printf("queue is full\n");
	
	}
	else if(*r==-1 && *f==-1)
	{
		*r=0;
		*f=0;
		que *temp=createnode();
		*t=temp;
	}	
	else
	{
		if(*r==limit-1 && *f>0)
		{
			*r=-1;
		}
		que *temp=createnode();
		(*r)++;
		que *temp1=*t;
		while(temp1->next!=*t){
		temp1=temp1->next;
		}
		temp1->next=temp;
		temp->next=*t;
		*t=temp;
		
	}
		
}

void display(que *t)
{	if(t!=NULL)
	{	
		printf("head= %d|%lu-->>",t->x,t);
		que *temp=t->next;	
		while(temp!=t)
		{
			printf(" %d|%lu-->>",temp->x,temp->next);
			temp=temp->next;
		}
	}	
printf("\n");	
}
