#include<stdio.h>
#include<stdlib.h>

typedef struct doublell{
	int x;
	struct doublell *prev;
	struct doublell *next;

}dll;
void insertATend(dll**);
void display(dll*);
void insertatbeg(dll**);
dll *createnode();
void insertatpos(dll**);
void delAtbeg(dll**);
void delAtpos(dll**);
void delAtend(dll**);


int main(){
	dll *head=NULL;
	int choice;
	
	while(1){
		printf("\n 1:Add at end 2:display 3:add at beg 4:add at pos 5:del at beg 6:del at pos 7:del At end 8:exit\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insertATend(&head);
				break;
			case 2:
				display(head);
				break;
			case 3:
				insertatbeg(&head);
				break;
			case 4:
				insertatpos(&head);
				break;	
			case 5:
				delAtbeg(&head);
				break;	
			case 6:
				delAtpos(&head);
				break;	
			case 7:
				delAtend(&head);
				break;	
			case 8:
				exit(0);
				break;
			default:
				printf("enter good choice\n");
				break;
		}
	}
}

dll * createnode(void){
	dll *temp;
	
	printf("\nenter a number\n");
	temp=(dll*)malloc(sizeof(dll));		
	scanf("%d",&(temp->x));	
	temp->prev=NULL;
	temp->next=NULL;
	return temp;
}

void delAtbeg(dll**t)
{
	if(*t==NULL)
	{
		printf("no node left\n");
		return;
	}
	if((*t)->next==NULL)
	{
		free(*t);
		*t=NULL;
		return;

	}
	dll *temp;
	temp=*t;
	*t=temp->next;
	(*t)->prev=NULL;
	free(temp);

}

void delAtend(dll **t)
{
	
	if(*t==NULL)
	{
		printf("no node left\n");
		return;
	}
	if((*t)->next==NULL)
	{
		free(*t);
		*t=NULL;
		return;

	}

	dll *temp=*t;
	while(temp->next->next != NULL)
	{
		temp=temp->next;
	}
	free(temp->next);
	temp->next=NULL;
}

void delAtpos(dll **t)
{
	
	int pos;
	printf("enter position\n");
	scanf("%d",&pos);
	if(pos==1){

		delAtbeg(t);
		return;
	}

	dll *temp1=*t,*temp2;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
		if(temp1->next==NULL)
		{      
			if(pos==1)
			{
			delAtend(t);
			return;
			}
			else 
			{
			printf("enter valid position\n");
			return;
			}
		}
	}
	temp1->next->prev=temp2;
	temp2->next=temp1->next;
	free(temp1);

}

void insertatbeg(dll **t){
	dll *temp=createnode();
	if(*t==NULL){
		*t=temp;
	}
	else
	{
	temp->prev=NULL;
	temp->next=*t;
	(*t)->prev=temp;
	*t=temp;
	}
}

void insertATend(dll **t){
	dll *temp=createnode();
	if(*t==NULL){
		*t=temp;
	}
	else
	{
	dll *temp1=*t;
	while(temp1->next!=NULL){
		temp1=temp1->next;
	}
	temp1->next=temp;
	temp->prev=temp1;
	}
}

void insertatpos(dll **t){

	int pos;
	printf("enter position\n");
	scanf("%d",&pos);
	if(pos==1){

		insertatbeg(t);
		return;
	}

	dll *temp1=*t,*temp2;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
		if(temp1==NULL)
		{      
			if(pos==1)
			{
			insertATend(t);
			return;
			}
			else 
			{
			printf("enter valid position\n");
			return;
			}
		}
	}
	dll *temp=createnode();
	temp->prev=temp2;
	temp->next=temp1;
	temp2->next=temp;
	temp1->prev=temp;	
}

void display(dll *t){

	while(t!=NULL)
	{
		printf(" %lu--%d--%lu \n",t->prev,t->x,t->next);
		t=t->next;
	}
	
}
