#include<stdio.h>
#include<stdlib.h>
#define limit 5

void push(int x[],int *top){
	
	if(*top<limit)
	{
		(*top)++;
		printf("enter the no:");
		scanf("%d",&x[(*top)]);
	}
	else
	{
		
	printf("stack is full:\n");
	}
}
void pop(int *top){
	if(*top >= 0)
	{	
		(*top)--;
		
	}
	else
		printf("stack is empty\n");




}

void display(int a[],int top)
{
	for(int i=top;i>=0;i--)
	{
		printf("| %d | \n",a[i]);
	}
	
}

int main(){
	int ch,a[limit],top=-1;
	printf("enter choice\n");
	while(1)
	{
	printf("1.push() 2.pop() 3.display() 4.exit\n");

	scanf("%d",&ch);
	switch(ch){

		case 1:
			push(a,&top);
			break;
		case 2:
			pop(&top);
			break;
		case 3:
			display(a,top);
			break;
		case 4:
			exit(0);
			break;
		default:
			printf("enter correct choice");
		}

	}
}
