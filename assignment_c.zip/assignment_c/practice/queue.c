
#include<stdio.h>
#include<stdlib.h>
#define limit 5

typedef struct queue{
	int x;
	struct queue *next;

}que;

que* createnode(void);
void insert(que** ,int*,int*);
void display(que*);
void delete(que**,int*,int*);


int main()
{
	que *point=NULL;
	int f=-1,r=-1,choice;
	while(1)
	{
	printf("1:insert 2:delete 3:display 4:exit\n");
	scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insert(&point,&f,&r);
			break;	
			case 2:
				delete(&point,&f,&r);
			break;	
			case 3:
				display(point);
			break;	
			case 4:
				exit(0);
			break;	
		}
}}



que * createnode(void){
	que *temp;
	printf("\nenter a number\n");
	temp=(que*)malloc(sizeof(que));		
	scanf("%d",&(temp->x));	
	temp->next=NULL;
	return temp;
}
void delete(que **head,int *f,int *r)
{	if(*f!=-1){
		if(*f==*r){
			*f=-1;
			*r=-1;
			}
		if(*head!=NULL)
			{	
				que *temp=*head;
				temp=temp->next;
				free(*head);
				*head=temp;
			}
		else
			printf("queue is empty\n");	
		*f=*f+1;
	  	}
}
void insert(que **t,int *f,int *r)
{	
	if(*r<limit-1)
	{
		que *temp=createnode();
		if(*t==NULL)
		{
			*t=temp;
			*f=0;
		}
		else
		{	
			que *t1=*t;
			while(t1->next != NULL)
			{
				t1=t1->next;
			}
		t1->next=temp;	
		}
		(*r)++;
	}
	else
	{
		printf("queue is full\n");
	}
}

void display(que *t)
{
	while(t!=NULL)
	{
		printf(" -<<< %d -<<",t->x);
		t=t->next;
	}	
	printf("\n");
}	
