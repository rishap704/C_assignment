#include<stdio.h>
#include<stdlib.h>
#define limit 6

void insert(int a[],int *f,int *r){
	
	if (*r==-1)
		*f=0;

	if(*r==limit-1 && (*f==0 || *f==*r+1))
	{
		printf("queue is full\n");
		return;
	
	}

	if(*r==limit-1)
		*r=-1;
	printf("enter a number\n");
	(*r)++;
	scanf("%d",&a[*r]);

}
void delete(int *f,int *r){
	if(*f==-1)
	{
		printf("*f=%d",*f);
		printf("queue is empty\n");
	}
	if(*f==*r||*f==-1)
	{	*f=-1;
		*r=-1;
		return;
	}
	if(*f==limit-1)
		*f=-1;
	

	(*f)++;
	

}

void display(int a[],int f,int r)
{
	if(r>f)
	{
		for(int i=f;i<=r && r>-1;i++)
		{
			printf("| %d | ",a[i]);
		}
	}
	else if(f==r)
	{
		for(int i=f;i<=r;i++)
		{
			printf("| %d | ",a[i]);
		}	
	}
	else
	{
		for(int i=0;i<=r;i++)
		{
			printf("| %d | ",a[i]);
		}
	}
}

int main(){
	int ch,a[limit],f=-1,r=-1;
	printf("enter choice\n");
	while(1)
	{
	printf("1.insert 2.delete 3.display() 4.exit\n");

	scanf("%d",&ch);
	switch(ch){

		case 1:
			insert(a,&f,&r);
			break;
		case 2:
			delete(&f,&r);
			break;
		case 3:
			display(a,f,r);
			break;
		case 4:
			exit(0);
			break;
		default:
			printf("enter correct choice\n");
		}

	}
}

