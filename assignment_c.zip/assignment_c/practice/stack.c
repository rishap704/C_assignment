#include<stdio.h>
#include<stdlib.h>
#define full 9

typedef struct stack{
	int x;
	struct stack *next;

}stack;

stack* createnode(void);
void push(stack** ,int*);
void display(stack* ,int );
void pop(stack**,int*);


int main()
{
	stack *point=NULL;
	int top=-1,choice;
	while(1)
	{
	printf("1:push 2:pop 3:display 4:exit\n");
	scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				push(&point,&top);
			break;	
			case 2:
				pop(&point,&top);
			break;	
			case 3:
				display(point,top);
			break;	
			case 4:
				exit(0);
			break;	
		}
	}
}

stack * createnode(void){
	stack *temp;
	char buff[50];        
	int x;
	printf("\ninteger data\n");
	temp=(stack*)malloc(sizeof(stack));	
	scanf("%d",&temp->x);	
	temp->next=NULL;
	return temp;
}

void push(stack **point,int *x){
	if(*x<full)
	{
	stack *temp;
	temp=createnode();
 	temp->next=*point;
	*point=temp;
	*x=*x+1;
	}
	else 
		printf("stack is full\n");

}

void pop(stack **point,int *top){
	
	if(*top>=0)
	{
	stack *temp;
	temp=*point;
	*point=(*point)->next;
	free(temp);
	(*top)--;
	}
	else
	{
		printf("stack empty!!!\n");
	}	
}

void display(stack *p,int top)
{
	while(top>=0)
	{
		printf("%d  | %d |\n",top,p->x);
		p=p->next;
		top--;
	}
	printf("___________\n");
}
