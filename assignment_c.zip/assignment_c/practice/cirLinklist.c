#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <stdio_ext.h>


typedef struct node{
	int x;
	struct node *next;
}cir;

void insertATend(cir**);
void display(cir*);
void insertatbeg(cir**);
cir *createnode();
void insertatpos(cir**);
void delAtbeg(cir**);
void delAtpos(cir**);
void delAtend(cir**);

int main(){
	cir *head=NULL;
	int choice;
	
	while(1){
		printf("\n 1:Add at end 2:display 3:add at beg 4:add at pos 5:del at beg 6:del at pos 7:del At end 8:exit\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insertATend(&head);
				break;
			case 2:
				display(head);
				break;
			case 3:
				insertatbeg(&head);
				break;
			case 4:
				insertatpos(&head);
				break;	
			case 5:
				delAtbeg(&head);
				break;	
			case 6:
				delAtpos(&head);
				break;	
			case 7:
				delAtend(&head);
				break;	
			case 8:
				exit(0);
				break;
			default:
				printf("enter good choice\n");
				break;
		}
	}
}


void delAtbeg(cir **head)
{
	if(*head==NULL)
		return;
	if((*head)->next!=*head)
	{
	cir *temp=*head,*temp1;
	temp=temp->next;
		temp1=temp;
		while(temp1->next!=*head)
		{
			temp1=temp1->next;
		}

		temp1->next=temp;
		free(*head);
		*head=temp;
	}
	else
	{
		if(*head!=NULL)
		{
			*head=NULL;
			return;
		}
	printf("\nno node left\n");
	}
}

void delAtpos(cir **t){
	int pos;
	
	if(*t==NULL){
		printf("no node left\n");
		return;
	}
	
	printf("enter position\n");
	scanf("%d",&pos);
	cir *temp1,*temp2;
	temp1=*t;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
		if(temp2->next==*t)
		{
			if(pos==1 && temp1->next!=*t)
			{
				delAtend(t);
			return;
			}
			else
			{
			printf("enter valid position\n");
			return;
			}
		}
	}
	temp2->next=temp1->next;
	if(temp1==*t)
	{
		delAtbeg(t);
	}
	free(temp1);
	
}

void delAtend(cir **t)
{
	cir *temp1,*temp2;
	if((*t)->next==*t)
	{
		delAtbeg(t);
	}
	temp1=*t;
	while(temp1->next != *t)
	{
		temp2=temp1;
		temp1=temp1->next;
	}
	temp2->next=temp1->next;
	free(temp1);
}

void insertatpos(cir **t){
	int pos;
	printf("enter position\n");
	scanf("%d",&pos);
	if(pos==1)
	{
		insertatbeg(t);
		return;
	}

	cir *temp1,*temp2;
	temp1=*t;
	while(pos-1){
		temp2=temp1;
		temp1=temp1->next;
		pos--;
		if(temp2->next==*t)
		{
			if(pos==1)
			{
			insertATend(t);
			return;
			}
			else
			{
			printf("enter valid position\n");
			return;
			}
		}
	}
	cir *temp=createnode();
	temp->next=temp1;
	temp2->next=temp;
}

void insertatbeg(cir **t){

	cir *temp=createnode();
	cir *temp1=*t;
	if(*t!=NULL)
	{
	while(temp1->next!=*t){
	temp1=temp1->next;
	}
	temp1->next=temp;
	temp->next=*t;
	}
	*t=temp;
}


cir * createnode(void){
	cir *temp;
	
	printf("\nname,id,sal and year of employee\n");
	temp=(cir*)malloc(sizeof(cir));		
	scanf("%d",&(temp->x));	
	temp->next=temp;
	return temp;
}
void insertATend(cir **t)
{	
	cir *temp=createnode();
	if(*t==NULL)
	{
		*t=temp;
	}
	else
	{	
		cir *t1=*t;
		while(t1->next != *t)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->next=*t;	
	}
}

void display(cir *t)
{	if(t!=NULL)
	{	
		printf("head= %d|%lu-->>",t->x,t);
		cir *temp=t->next;	
		while(temp!=t)
		{
			printf(" %d|%lu-->>",temp->x,temp->next);
			temp=temp->next;
		}
	}	
	
}





















