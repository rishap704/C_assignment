#include<stdio.h>

struct tre{
	int x;
	struct tre *left;
	struct tre *right;
};

int main(){
	struct tre *r=NULL;


}

void createnode(){
	int d;
	printf("enter data\n");
	scanf("%d",&d);
	r=(struct tre*)malloc(sizeof(struct tre));
	r->x=d;
	r->left=NULL;
	r->right=NULL;
}
void insert(struct tre **r,int ele){
	struct tre *temp;
	temp=createnode();
	if(*r==NULL)
	{
		*r=temp;
	}
	else if(ele<(*r)->x)
		insertleft();
	else
		insertright();
}
insertleft(){



}

void insertright(struct tre **r,)
{
	while((*r)->right!=NULL)
	{
		(*r)=(*r)->right;
	}
	if(ele<(*r)->data)
        *





}
