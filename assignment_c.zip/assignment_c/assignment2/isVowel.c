#include<stdio.h>
#include<string.h>

int main()
{
	char ch;
	printf("Enter Alphabet");
	scanf("%c",&ch);
	switch(ch)
	{
		case 'a':
		printf("%c is a vowel",ch);
		break;
		case 'e':
		printf("%c is a vowel",ch);
		break;
		case 'i':
		printf("%c is a vowel",ch);
		break;
		case 'o':
		printf("%c is a vowel",ch);
		break;
		case 'u':
		printf("%c is a vowel",ch);
		break;
		default:
		printf("Not a vowel");
		break;
	}
	return 0;

}
