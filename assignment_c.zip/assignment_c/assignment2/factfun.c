#include<stdio.h>
int fact(int a){
	int fact=1;
	for(;a>1;a--)
		fact=fact*a;
	return fact;
}
