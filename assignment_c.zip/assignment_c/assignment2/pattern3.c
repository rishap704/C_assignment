#include<stdio.h>
int main() {
int n;
printf("enter a number");
scanf("%d",&n);
int k=n;
for(int i=1;i<=n;i++){
	for(int j=1;j<k;j++)
		printf(" ");
	for(int l=0;l<2*i-1;l++)
		printf("%d",i);
	printf("\n");
	k--;
}
return 0;








}
