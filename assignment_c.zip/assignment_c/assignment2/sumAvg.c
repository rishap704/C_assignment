#include<stdio.h>

int sum(int*,int);
int avg(int*,int);

int main(){
	int n,arr[50];
printf("enter the count of number");
scanf("%d",&n);
printf("enter the numbers");
for(int i=0;i<n;i++)
	scanf("%d",&arr[i]);
printf("sum is %d \n",sum(arr,n));
printf("average is %d \n",avg(arr,n));
}
int sum(int arr[],int n){
	int sum=0;
	for(int i=0;i<n;i++)
		sum=sum+arr[i];
          return sum;
}
int avg(int arr[], int n){
	int avg;
	avg= sum(arr,n)/n;
	return avg;
}

