
#include<stdio.h>
int fact(int);
int main(){
int n;
printf("enter number");
scanf("%d",&n);
printf("factorial od %d is",fact(n));
return 0;
}
