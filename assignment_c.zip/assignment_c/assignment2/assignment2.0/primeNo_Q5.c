#include<stdio.h>
int main(){
	int num1,i=2;;
	printf("enter a number\n");
	scanf("%d",&num1);
	if(num1==2)
	{
		printf("%d is prime no\n",num1);
		return;
	}
	while(i<num1){
		if(num1%i!=0)
			i++;
		
		else 
		{
			printf("%d is not a prime number\n",num1);
			return;
		}
		

	}
	printf("%d is prime no\n",num1);
	return 0;
	}






