#include<stdio.h>


int main(){
	int num1,i=0,sum=0;
	printf("enter a number\n");
	scanf("%d",&num1);
	int num=num1;

	for(int j=1;j<=num1;j++)
	{

		if(num1%j==0)
		{
		sum=sum+j;
		}
		
	}
	printf("%d\n",sum);
	if(sum/2==num)
		printf("%d is perfect number\n",num);
	else
		printf("%d is not a perfect no\n",num);

	return 0;



}






