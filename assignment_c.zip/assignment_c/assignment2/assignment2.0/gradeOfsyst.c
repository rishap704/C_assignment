#include<stdio.h>
int main(){
	int n,a[50],sum=0;
	printf("enter number of subjects");
	scanf("%d",&n);
	printf("enter the marks obtained in %d subjects",n);
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(int i=0;i<n;i++){
		sum=sum+a[i];
	}
	sum=sum/n;
	if(sum>90)
		printf("grade A\n");
	else if (sum>80)
		printf("grade B\n");
	else if(sum>70)
		printf("grade C\n");
	else if(sum>60)
		printf("grade D\n");
	else
	        printf("Fail\n");		
	return 0;




}
