#include<stdio.h>

int recsum(int x){
	int a,r,sum=0;
	while(x){
	r=x%10;
	x=x/10;
	sum=sum+r;
	}
	if(sum>9)
	{
	recsum(sum);
	}
	else
	{
	printf("recursive sum of %d \n",sum);
		
	}

	return sum;
}



int main(){
	int num1;
	printf("enter a number\n");
	scanf("%d",&num1);
	recsum(num1);
	//printf("recursive sum of %d is %d\n",num1,recsum(num1));

}

