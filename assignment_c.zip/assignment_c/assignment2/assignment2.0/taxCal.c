#include<stdio.h>

int main(){
	float tax;
	char gender,snr,inv;
	printf("enter total tax:");
	scanf("%f",&tax);
	printf("type: m or f");
	
	scanf("%*c%c",&gender);
	printf("if senior citizen: y or n");	
	scanf("%*c%c",&snr);
	printf("if any investment: y or n");
	scanf("%*c%c",&inv);

	if(gender=='f')
	{
		tax=tax-(tax*0.1);
	}
	else
	{
		tax=tax-(tax*0.05);	
	}
	
	if(snr=='y')
	{
		tax=tax-(tax*0.2);
	}
	
	if(inv=='y')
	{
		tax=0;
	}
	
	printf("\n total tax to be paid::%.3f\n",tax);
	return 0;
}

