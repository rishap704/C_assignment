
#include<stdio.h>
int main(){
	int num;
	printf("enter a number\n");
	scanf("%d",&num);
	int i=3,flag=1;
	while(num)
	{
	
			flag=1;
	for( ;flag!=-1;i++){
		
		for(int j=2;j<i;j++)
		{	if(i%j==0)
			{
				flag =0;
				break;
			}
			else
				flag=-1;
		}
		if(flag==-1)
		{
			printf("%d ",i);
		}
	}
	num--;
	}	

			
		
	
}
