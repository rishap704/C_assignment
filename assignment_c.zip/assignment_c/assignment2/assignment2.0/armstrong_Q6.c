#include<stdio.h>

int main(){
	int num1,r[20],i=0,sum=0;
	printf("enter a number\n");
	scanf("%d",&num1);
	int num=num1;
	while(num1)
	{
		r[i]=num1%10;
		num1=num1/10;
		i++;
	}

	for(int j=0;j<i;j++)
	{

		sum=sum+(r[j]) * (r[j]) * (r[j]);
	}
	if(sum==num)
		printf("%d is armstrong number\n",num);
	else
		printf("%d is not a armstrong no\n",num);

	return 0;



}
