#include<stdio.h>
int main(){
	int num1,num2,num3;
	printf("enter three numbers");
	scanf("%d%d%d",&num1,&num2,&num3);
	if(num1>num2 && num1>num3)
	    	 printf("biggest number among three is %d \n",num1);
	if(num2>num3)		
		printf("biggest number among three is %d \n",num2);
	else		
		printf("biggest number among three is %d \n",num3);	
	return 0;
}
