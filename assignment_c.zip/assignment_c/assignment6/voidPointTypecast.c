#include<stdio.h>

int main()
{
	int a=0x0f1f0506;
	float b=12.56;
	char c='r';

	void *p;
	p=&a;

	printf("\nvalue of a%x",*((char*)p));
	printf("\nvalue of a%x",*((char*)p+1));
	printf("\nvalue of a%x",*((char*)p+2));
	printf("\nvalue of a%x",*((char*)p+3));
	//printf("\n*p of p%u",*p);
	return 0;
}
