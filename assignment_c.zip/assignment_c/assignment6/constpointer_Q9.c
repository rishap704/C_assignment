#include<stdio.h>

int main()
{      int x=10,y=20;
//	const int *p=&x;
//	int const *p=&x;
	int *const p=&x;
//	const int *const p=&x;
         x=20;
	printf("*p=%d",*p);
//	p++;
//	printf("p++=",p);
//	(*p)++;
//	printf("(p*)=",);
return 0;
}
