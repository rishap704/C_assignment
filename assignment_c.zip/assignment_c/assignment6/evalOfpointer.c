#include<stdio.h> 

int main()
{
	int a[5]={10,20,30,40,50};
	int *p=a,*q=*(&a+1)-1;
	printf("\np=%u",p);
	printf("\np=%u",q);
	printf("\n*p=%d",*p);
	printf("\n*p++=%d",*p++);
	printf("\n*++p=%d",*++p);
	printf("\n(*p)++=%d",(*p)++);
	printf("\n++(*p)=%d",++(*p));
	printf("\n++*p=%d",++*p);
	printf("\n*(p++)=%d",*(p++));
	printf("\n*(++p)=%d",*(++p));
	printf("\n*q--=%d",*q--);
	printf("\n*--q=%d",*--q);
	printf("\n--(*q)=%d",--(*q));
	printf("\n--*q=%d",--*q);
	printf("\n(*q)--=%d",(*q)--);
	printf("\n*(q--)=%d",*(q--));
	printf("\n*(--q)=%d",*(--q));
	return 0;



}
