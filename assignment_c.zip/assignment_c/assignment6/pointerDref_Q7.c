#include<stdio.h>

int main()
{
	int arr[5],(*parr)[5];
	parr=&arr;
	printf("\n sizeof(parr)::%u",sizeof(parr));
	printf("\n sizeof(*parr)::%u",sizeof(*parr));
	printf("\n sizeof(**parr)::%u",sizeof(**parr));
	return 0;
}
