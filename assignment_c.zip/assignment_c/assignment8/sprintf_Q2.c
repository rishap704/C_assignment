#include<stdio.h>


int main()
{
	int x=99;
	char result[100],name[20];

	///////**********string concatnation and its length******///////

	char pr[]="my name is %s and rollno=%d";
	scanf("%[^\n]s",name);
	x=sprintf(result,pr,name,x);
	printf("\n %s length=%d",result,x);
	{
		int x=10;
	}
	///////////////string copy///////////////////
	char cp1[12],*cp2="hello rishap%d \n";
	sprintf(cp1,cp2,x);
	printf("\n %s",cp1);
	return 0;
}
