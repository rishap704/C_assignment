#include<stdio.h>
#include<string.h>
int mynoOfcharocc(const char*,const char);
char *mystrrev(char*);
int mystrlen(const char*);
char *mystrcpy(char*,const char*);
char *mystrcat(char*,const char*);
int mystrcmp(char*,char*);
int my1charoccur(const char*,const char);
char *substr(const char *,const char* );
int substrcheck(const char*,const char*);

int main(){
	char name[20]="abcdefg",*str,src[]="mnopqr",cpystr[10];
	int len;
	
	printf("\n original string is %s\n",name);
	str=mystrrev(name);
	printf("\n reverse of str is %s\n",str);
	len=mystrlen(name);
	printf("lenth of str is %d\n",len);
	
	str=mystrcpy(name,src);
	printf("\n str is %s\n",str);
	printf("\n name is %s\n",name);
	
	str=mystrcat(name,src);
	printf("\n str is %s\n",str);
	printf("\n name is %s\n",name);

	len=mystrcmp(name,src);
	printf("value is %d",len);
	
	len=my1charoccur(name,'n');
	printf("occurence of q is %d \n",len);
	
	len=mynoOfcharocc(name,'m');
	printf("no of occurance is %d \n",len);

	char *temp=substr(name,"abcde");
	printf("substr is=%s\n",temp);

	substrcheck(name,"rmn");

	return 0;
}
int mystrlen(const char *p){
	int len=0;
	while(*p!='\0'){
	len++;
	p++;
	}
	return len;
}
char *mystrcpy(char *dest,const char *src){
	int len=mystrlen(src);
	while(*src!='\0'){
	*dest=*src;
	dest++;
	src++;
	}
	*dest='\0';
	return dest-len;
}

char *mystrcat(char *dest,const char *src){
	int len=mystrlen(src)+mystrlen(dest);

	while(*dest!='\0'){
	dest++;
	}
	while(*src!='\0'){
	*dest++=*src++;
	}
	*dest='\0';
	return dest-len;
}

char *mystrrev(char *p){
	int len,i=0;
	char temp;
	len=strlen(p);
	while(i<len/2){
		temp=*(p+i);
		*(p+i)=*(p+len-i-1);
		*(p+len-i-1)=temp;
		++i;
	}
	return p;
}
int mystrcmp(char*str1,char*str2){
	int i=0,n=0;
	while(i< mystrlen(str1)){
		if(*(str1+i)==*(str2+i)){
	        i++;
		}
		else return n=*(str1+i)-*(str2+i);
	}		
}

int my1charoccur(const char *str,const char ch)
{
	int pos=0,a=mystrlen(str);
	printf("length is %d\n",a);
	while(a--)
	{
		if(*(str+a) == ch){
			return mystrlen(str)-pos;
		}
		pos++;
	}
	return 0;

}
int mynoOfcharocc(const char *str,const char ch){
	
	int count=0,i=0;
	while(*(str)!=0){
		if(*(str)==ch){
			count++;
		//	i++;
		}
		str++;
	}
	return count;

}

char *substr(const char *str1,const char *str2)
{	
	int count=0;
	while(*str1!='\0')
	{
		if(*(str1+count)==*(str2+count))
		{
			count++;
				if(count==(mystrlen(str2)-1))
				{
					return (char*)str1;
				}
					
		}
		else
		{
			count=0;
			str1++;
		}
	}
	return NULL;
}

int substrcheck(const char*str1,const char*str2){
	int i=0;
	if(*str1==*str2)
	{
		while(*str2!='\0')
		{
			if(*(str1+i)==*(str2+i))
			{
				i++;
			}
			else
			{
				break;
			}
		}
		if(i==mystrlen(str2))
		{
			printf("substring match::at start\n");
			return 1;
		}

	}
	i=1;
	if(*(str1+mystrlen(str1)-1)==*(str2+mystrlen(str2)-1))
	{
		while(i<mystrlen(str2))
		{
			if(*(str1+mystrlen(str1)-i)==*(str2+mystrlen(str2)-i))
			{
				i++;
			}
			else
			{
				break;
			}
		}
		if(i==mystrlen(str2))
		{
			printf("substring match::at end\n");
			return 1;
		}
	}
	printf("substring not matched\n");
	return 0;
}
