#include<stdio.h>
#include<stdlib.h>
int main()
{
	char stri[]="8521",strli[]="95137",strlli[]="98765432",strfl[]="752.568";
	int i=atoi(stri);
	printf("\n sizeof(%s)=%ld and sizeof(int i=%d)=%ld",stri,sizeof(stri),i,sizeof(i));
	
	long int j=atol(strli);
	printf("\n sizeof(%s)=%ld and sizeof(long int i=%ld)=%ld",strli,sizeof(strli),j,sizeof(j));
	
	long long int k=atoll(strlli);
	printf("\n sizeof(%s)=%ld and sizeof(long long int k=%lld)=%ld",strlli,sizeof(strlli),k,sizeof(k));
	
	float f=atof(strfl);
	printf("\n sizeof(%s)=%ld and sizeof(float f=%f)=%ld",strfl,sizeof(strfl),f,sizeof(f));

	char strb[]="2536sdf",*nptr,*eptr;
	i=strtoimax(strb,&eptr,8);
	printf("\n sizeof(%s)=%d and sizeof(int i=%d)=%d",strb,sizeof(strb),i,sizeof(i));
	printf("\n eptr=%s",eptr);
	
	j=strtol(strb,&eptr,16);
	printf("\n sizeof(%s)=%d and sizeof(int i=%d)=%d",strb,sizeof(strb),j,sizeof(j));
	printf("\n eptr=%s",eptr);
/*	
	unsigned long int k=atoll(strlli);
	printf("\n sizeof(%s)=%ld and sizeof(long long int k=%lld)=%ld",strlli,sizeof(strlli),k,sizeof(k));
	float f=atof(strfl);
	printf("\n sizeof(%s)=%ld and sizeof(float f=%f)=%ld",strfl,sizeof(strfl),f,sizeof(f));
	
*/	return 0;
}
