#include<stdio.h>
#include<string.h>


int main()
{

	char str1[20]="hello",str2[20]="rishap";

	///***********strncpy****************///
	char dest[20]="iugdsf",*p,*q;
	printf("\ndest=%s",dest);
	p=strncpy(dest,str1,4);
	printf("\ndest=%s",dest);
	printf("\np=%s\n",p);

	///***********strcpy****************///
	p=strcpy(dest,str1);
	printf("\ndest=%s",dest);
	printf("\np=%s\n",p);
	
	///***********strncat****************///
	q=strncat(dest,str2,3);
	printf("\n %s",dest);


	///***********strncmp****************///
	strcpy(str1,"cdac ");
	strcpy(str2,"Cdacacts");
	int diff=strncmp(str1,str2,4);
	printf("\n q=%d",diff);
	
	//************strncasecmp***************
	diff=strncasecmp(str1,str2,4);
	printf("\n q=%d",diff);

	//************strchr***************
	char *ch=strchr(str1,'a');
	printf("\n ch=%lu *ch=%c",(long unsigned)str1,*(str1+2));

	printf("\n ch=%lu *ch=%c",(long unsigned)ch,*ch);

	//************strrchr***************
	ch=strrchr(str1,'c');
	printf("\n ch=%lu *ch=%c",(long unsigned)str1,*(str1+2));

	printf("\n ch=%lu *ch=%c",(long unsigned)ch,*ch);

	
	//************strstr***************
	strcpy(str1,"act");
	ch=strstr(str2,str1);
	printf("\n str2=%lu  %s",(long unsigned)str2,str2);

	printf("\n ch=%lu *ch=%s",(long unsigned)ch,ch);
	
	//************strtok***************
	strcpy(str1,"hrs::min::sec");
	strcpy(str2,"::");
	ch=strtok(str1,str2);
	printf("\n ch=%lu *ch=%s",(long unsigned)ch,ch);

	ch=strtok(NULL,str2);
	printf("\n ch=%lu *ch=%s",(long unsigned)ch,ch);
	ch=strtok(NULL,str2);
	printf("\n ch=%lu *ch=%s",(long unsigned)ch,ch);
	
	///********************snprintf************
	strcpy(str1,"cdac");
	int k=2;
	snprintf(str1,20,"num %d is even ",k);
	printf("\n %s \n",str1);
	
	///**************sscanf*********
	char st1[20]="hellorishap 4",st[20],st2[10];
        sscanf(st1,"%so%s %d",st,st2,&k);
	printf("%s\n",st);
	printf("%s\n",st2);
	printf("%d\n",k);

return 0;
}
