#include<stdio.h>
int main(){
	char userChar;
	printf("enter character");
	scanf("%c",&userChar);

	printf("ASCII of %c=%d \n",userChar,userChar);
	return 0;
}
