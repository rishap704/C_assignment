#include<stdio.h>
int main(){
int x,y,temp;
printf("enter two numbers");
scanf("%d%d",&x,&y);
//with temp variable
temp=x;
x=y;
y=temp;
printf("x=%d y=%d \n",x,y);
//without temp variable
printf("enter two numbers");
scanf("%d%d",&x,&y);
x=x+y;
y=x-y;
x=x-y;
printf("x=%d y=%d \n",x,y);
return 0;
}


