#include<stdio.h>
void main()
{
		int arr[10];
		for(int i=0;i<5;i++) 
		scanf("%d[^ ],&arr[i]");
		for(int j=0;j<5;j++)
		printf("%d",arr[j]);
}
