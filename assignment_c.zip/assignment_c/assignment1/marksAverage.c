#include<stdio.h>
int main(){
	int marks[5],i;
	float average=0;
	printf("enter 5 subject marks \n");
	for(i=0;i<5;i++){
	scanf("%d",&marks[i]);
	}
	
	average=(float)(marks[0]+marks[1]+marks[2]+marks[3]+marks[4])/5;
	printf("Marks Average=%f",average);
	return 0;
}
