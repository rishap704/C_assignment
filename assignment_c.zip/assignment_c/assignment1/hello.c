#include<stdio.h>
int main(){
printf("hello\tworid\n");
printf("hello \r world \n");
printf("he\bllo world\n");
printf("\\\n");
return 0;


}
