#include<stdio.h>
int main(){
	int num1,num2,sum;
	printf("enter two numbers \n");
	scanf("%d %d",&num1,&num2);
	sum=num1+num2;
	printf("sum=%d \n",sum);
	return 0;
}
