#include<stdio.h>

float percent(float sal,int per){
	float result=0;
	result=(sal*per)/100;
	return result;
}
int main(){
	long int salary=0;
	float hra,da,pf,gs,netSal;
	printf("Enter the Basic salary \n");
	scanf("%ld",&salary);
	hra=percent(salary,20);
	da=percent(salary,40);
	gs=salary+hra+da;
	pf=percent(gs,10);
	netSal=gs-pf;
	printf("Net Salary=%f \n",netSal);
return 0;
}
