#include<stdio.h>
int main(){
	int num1,num2,digits1[5],digits2[5];
	long int sum=0;
	printf("Enter two numbers");
	scanf("%d%d",&num1,&num2);
	int i=0;
	do
	{
		digits1[i]=num1%10;
		num1=num1/10;
		i++;
	}
	while(num1);
	int j=0;
	do
	{
		digits2[j]=num2%10;
		num2=num2/10;
		j++;
	}
	while(num2);
	for(int k=0;k<i;k++)
	{
		for(int l=0;l<j;l++)
			sum=sum+digits1[k]*digits2[l];	
	
	}
	printf("SOP is=%ld \n",sum);
return 0;

}


