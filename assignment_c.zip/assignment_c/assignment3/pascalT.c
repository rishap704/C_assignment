#include<stdio.h>

int main()
{
	int arr[50]={1},arr2[50]={1},n=0;
	printf("ENTER A NUMBER\n");
	scanf("%d",&n);

	for(int i=0;i<=n;i++)
	{	
		
		for(int k=0;arr[k]!=0;k++)
		{
			arr2[k]=arr[k];
		}
		for(int j=0;j<n-i;j++)
		{
			printf(" ");
		}
		for(int k=0;k<=i;k++)
		{
			arr[k+1]=arr2[k+1]+arr2[k];
			printf("%d",arr2[k]);
			printf(" ");
		}
		printf("\n");
	}

}
