#include<stdio.h>
int main(){
int k,i,y,x,p,q;
printf("enter value of i,x,p");
scanf("%d%d%d",&i,&x,&p);
k=i++;
printf("k=i++ =%d\n",k);
k=++i;
printf("k=++i =%d\n",k);
y=x++*10;
printf("y=x++*10 =%d\n",y);
y=++x*10;
printf("y=++x*10 =%d\n",y);
q=p--/3;
printf("q=p--/3 =%d\n",q);
q=--p/3;
printf("q=p--/3 =%d\n",q);
}

