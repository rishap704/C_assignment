#include<stdio.h>
int main(){
int a,b,c;
printf("enter three numbers");
scanf("%d%d%d",&a,&b,&c);
(a>b&&a>c)?printf("%d is biggest",a):(b>c?printf("%d is biggest",b):printf("%d is biggest",c));
		return 0;


}
