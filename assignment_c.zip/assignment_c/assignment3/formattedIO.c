#include<stdio.h>

int main()
{
	int i=56;
	float f=25.2564;
	printf("int=%8di\n",i);
	printf("int=%05di\n",i);
	printf("int=%-5di\n",i);
	printf("float=%10.3ff\n",f);
	printf("float=%.2ff\n",f);
	return 0;
}
