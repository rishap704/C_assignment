#include<stdio.h>
int main(){
int x,y;
printf("enter two number");
scanf("%d%d",&x,&y);
x=x^x^y,y=y^y^x;

printf("x=%d & y=%d",x,y);
return 0;




}
