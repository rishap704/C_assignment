#include<stdio.h>

int main(){
	int hrs,min,sec;
	printf("enter time in hrs::min::sec \n ");
	scanf("%d%d%d",&hrs,&min,&sec);
	sec=(hrs*60*60)+(min*60)+sec;
	printf("total time in Seconds=%d \n",sec);

	hrs=sec/3600;
	min=(sec%3600)/60;
	sec=(sec%3600)%60;
	printf("hh:mm:ss %d::%d::%d",hrs,min,sec);
	return 0;
}
